#include <stdio.h>

int main() {
	int a = 1000;
	int b = 2000;
	int c = a + b;
	printf ("a + b = %d", c);
	c = c + 6000;

	return 0;
}
