int A = 10;
int B = 20;
int main ()
{
    int sum = A + B;
    return 0;
}
